class ApiFiltersSyntaxError(Exception):
    pass


class ApiSortingSyntaxError(Exception):
    pass