# 3DS Team - QueryBuilder

## Build

In the project root folder, using the venv interpreter:

    python -m pip install --upgrade build
    python -m build